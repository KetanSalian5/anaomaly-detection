from flask import Flask, request, jsonify
import numpy as np

app = Flask(__name__)

@app.route('/statistics', methods=['POST'])
def calculate_statistics():
    # Check if the request contains the required fields
    if 'data' not in request.json:
        return jsonify({'error': 'Invalid request. Missing data field.'}), 400
    
    # Get the data from the request
    data_str = request.json['data']
    
    try:
        # Split the string, remove the double quotes, and convert to float
        data = np.array([float(val.strip('"')) for val in data_str])
        
        # Calculate the mean and median
        mean = np.mean(data)
        median = np.median(data)

        # Prepare the response
        response = {
            'mean': mean,
            'median': median
        }

        return jsonify(response), 200
    
    except Exception as e:
        return jsonify({'error': 'An error occurred. ' + str(e)}), 500

if __name__ == '__main__':
    app.run()
